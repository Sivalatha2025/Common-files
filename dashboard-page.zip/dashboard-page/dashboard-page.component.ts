import { GetMastersAPI } from './../../constants/constants';
import { isPlatformBrowser } from '@angular/common';
import { AfterContentInit, Component, Inject, OnDestroy, OnInit, PLATFORM_ID } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { HelperModuleService } from 'src/app/auth/HelperModule/helpermodule.service';
import { APIPREFIX, GetControlsByModuleCode, GetDashBoardDetails, GetSchema, RootEnum } from 'src/app/constants/constants';
import { CommonService } from 'src/app/services/common/common.service';
import { MetaServiceService } from 'src/app/shared/SEO/meta-service.service';
import { StorageService } from 'src/app/storageService/storage-service';
import * as moment from 'moment';
import { EChartsOption } from 'echarts';
import { MultilanguageService } from 'src/app/services/multilanguage.service';
import { environment } from 'src/environments/environment';
declare var $: any

type XAxisLabelPosition = 'top' | 'bottom';
type YAxisLabelPosition = 'left' | 'right';

enum MasterData{
  stote='userstore',
  site='MainSite',
  Project = 'SupportTicketProject',
  Category = 'SupportTicketCategory',
  Healthcare = 'HealthHospital'
}
enum SchemaMasterGUID{
  schema='36077B96-A72C-4A0E-95C4-0CCF440F0B03',
  MainSiteSchema='9E4628C5-DE64-45F9-B813-C5EA4AC5078F'
}

enum StatisURLs{
  'TicketCRM'="/CRM/dashboard",
  'PatientsDashboard' = 'HealthCare/CustomerPatient/dashboard',
  'InventoryDashboard'= 'HealthCare/Inventory/dashboard'
}

@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.css']
})
export class DashboardPageComponent implements OnInit, AfterContentInit, OnDestroy {


  isBrowser: boolean = false;
  destroy$ = new Subject<void>();
  isModuleRes: boolean = false;
  moduleId: any;
  modulePermissionObj: any = {};
  moduleName: string = '';
  templeteCode: string = '';
  moduleCode: string = '';
  templeteCodeJson: string = '';
  templateName: string = '';
  title: string = '';
  apiPrefixURL: string = APIPREFIX;
  parentRecordId: any;
  url = '';
  moduleUrl: string = '';
  graphData: any;
  graphFields: any;
  chartsData: { [key: string]: any } = {};
  otherChartsData: { [key: string]: any } = {};
  graphTypesArray = ['verticalbar', 'horizontalbar', 'line', 'pie', 'donut', 'gauge'];
  chartsJSONData: { [key: string]: any } = {};
  chartOptions: { [key: string]: EChartsOption } = {};
  charts: any[] = [];
  fromDate: string = '';
  toDate: string = '';
  dropdownDataObj: any = {};
  changedetect : boolean = false;
  root: string = '';
  rootEnum = RootEnum;
  searchMasterFilter: any = [
    {
      MasterModuleCode: 'Store',
      MasterAPIUrl: "Getmasters",
      Id: 'userstore',
      DependantDropdown: 'SalesByCashRegister',
      Label: "Store",
      Type: 'multidropdown'
    },
    {
      MasterModuleCode: MasterData.site,
      MasterAPIUrl: "Getmasters",
      Id: MasterData.site,
      DependantDropdown: 'SalesByCashRegister',
      Label: "Site",
      Type: 'multidropdown'
    },
    {
      MasterModuleCode: 'HealthHospital',
      MasterAPIUrl: "Getmasters",
      Id: 'HealthHospital',
      DependantDropdown: '',
      Label: "Store",
      Type: 'multidropdown'
    },
  ]
  rootModule: string = '';
  selectedMasterDropDown: any = {};
  disableDropdownObj: any = {};
  chartDropdownvalue: any = {};
  isPermissionsLoaded : boolean = false;
  chartParentDropdownvalue:any = {};
  storeSettings: any = {
    singleSelection: false,
    idField: 'Id',
    textField: 'Name',
    selectAllText: 'Select All',
    unSelectAllText: 'Deselect All',
    itemsShowLimit: 1,
    allowSearchFilter: true
  };
  isPosDashboard:boolean = false;
  isSubmitLoading:boolean = false;
  isPageLoad:boolean = true;
  isTrackingDashboard:boolean = false;
  AllMasterData = MasterData;
  selectedCategory:any =[];
  selectedProject:any=null;
  staticurls = StatisURLs
  apiEndPointUrl:string='';


  constructor(private api: HelperModuleService,
    private storage: StorageService,
    private route: Router,
    private common: CommonService,
    private SEO: MetaServiceService,
    private actRoute: ActivatedRoute,
    private multiLanguageService : MultilanguageService,
    @Inject(PLATFORM_ID) private platformId: any,) {
    this.url = this.route.url;
    let rootUrl = this.actRoute.snapshot.params['root'] || '';
    let parentUrl = this.actRoute.snapshot.params['type'] || '';
    if (rootUrl && parentUrl) {
      this.moduleUrl = `${rootUrl}/${parentUrl}`;
    } else {
      this.moduleUrl = parentUrl;
    }
    this.root = this.route.url.split('/')[1];
  }

  ngAfterContentInit(): void {
    setTimeout(() => {
      if (isPlatformBrowser(this.platformId)) {
        $('#dashboardCalender').daterangepicker({
          startDate: moment().startOf('month'),
          endDate: moment().endOf('month'),
          opens: 'left',
          // maxDate: new Date(),
          showCustomRangeLabel: true,
          alwaysShowCalendars: true,
          autoUpdateInput: true,
          applyButtonClasses: 'clendr_apply_btn',
          cancelButtonClasses: 'clendr_cancel_btn',
          ranges: {
            Today: [moment(), moment()],
            Yesterday: [
              moment().subtract(1, 'days'),
              moment().subtract(1, 'days'),
            ],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(30, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [
              moment().subtract(1, 'month').startOf('month'),
              moment().subtract(1, 'month').endOf('month'),
            ],
            Quarterly: [moment().subtract(3, 'months').startOf('month'), moment()],
            'Half Yearly': [moment().subtract(6, 'months').startOf('month'), moment()],
          },
          locale: {
            format: 'DD/MMM/YYYY',
            separator: ' - ',
            applyLabel: 'APPLY',
            cancelLabel: 'CANCEL',
          },
        }, (start: any, end: any, label: any) => {
          // Callback function when a date range is selected
          this.onDateRangeSelected(start, end, 0);
        });
      }
    }, 1100);

  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.isBrowser = true;
    } else {
      this.isBrowser = false;
    }
    this.common.updateInnerRootModules.pipe(takeUntil(this.destroy$)).subscribe((res: any) => {
      if (res) {
        this.isModuleRes = true;
        this.isPageLoad = false;
        let url = this.route.url.replace('/', '');
        res.map((el: any) => {
          if (el.ModuleUrl == url) {
            let code = el;
            this.moduleId = el.ModuleId;

            this.moduleName = el?.ModuleName;
             this.isPermissionsLoaded = true;
            this.templeteCode = el?.TemplateCode || '';
            this.moduleCode = code?.ModuleCode || '';
            if (code?.JsonURL != undefined && code[0]?.JsonURL != null && code[0]?.JsonURL != '') {
              this.templeteCodeJson = code?.JsonURL;
            } else {
              this.templeteCodeJson = code?.TemplateCode + '.json';
            }
            this.templateName = code && code?.TemplateName;
            this.title = code && code?.ModuleName;
            this.parentRecordId = this.storage.getSessionStorage(this.moduleUrl + 'parentId') || ''
            this.apiEndPointUrl = el?.APIEndPointURL||'';
            this.getPermission();
          }
        })
        this.getParams();
      }
    });

    this.multiLanguageService.selectedLanguageUpdation()
    .pipe(takeUntil(this.destroy$))
    .subscribe(() => {
      
      this.changedetect = !this.changedetect;
    });

  }

  getParams() {
    this.actRoute.params.subscribe((param: any) => {

      setTimeout(() => {
        if (isPlatformBrowser(this.platformId)) {
          $('#dashboardCalender').daterangepicker({
            startDate: moment().startOf('month'),
            endDate: moment().endOf('month'),
            opens: 'left',
            // maxDate: new Date(),
            showCustomRangeLabel: true,
            alwaysShowCalendars: true,
            autoUpdateInput: true,
            applyButtonClasses: 'clendr_apply_btn',
            cancelButtonClasses: 'clendr_cancel_btn',
            ranges: {
              Today: [moment(), moment()],
              Yesterday: [
                moment().subtract(1, 'days'),
                moment().subtract(1, 'days'),
              ],
              'Last 7 Days': [moment().subtract(6, 'days'), moment()],
              'Last 30 Days': [moment().subtract(30, 'days'), moment()],
              'This Month': [moment().startOf('month'), moment().endOf('month')],
              'Last Month': [
                moment().subtract(1, 'month').startOf('month'),
                moment().subtract(1, 'month').endOf('month'),
              ],
              Quarterly: [moment().subtract(3, 'months').startOf('month'), moment()],
              'Half Yearly': [moment().subtract(6, 'months').startOf('month'), moment()],
            },
            locale: {
              format: 'DD/MMM/YYYY',
              separator: ' - ',
              applyLabel: 'APPLY',
              cancelLabel: 'CANCEL',
            },
          }, (start: any, end: any, label: any) => {
            // Callback function when a date range is selected
            this.onDateRangeSelected(start, end, 0);
          });
        }
      }, 100);

      this.graphData = [];
      this.graphFields = [];
      this.dropdownDataObj = {};

      this.intialAPICall()

      this.SEO.updateTags("", "", ' ' + '-' + ' ' + this.title);

      setTimeout(() => {
        // this.getSchema()
      }, 250);
    })
  }

  intialAPICall(){
    let startDate = moment().startOf('month');
    let endDate = moment().endOf('month');
    
    this.fromDate = startDate.format('DD/MM/YYYY');
    this.toDate = endDate.format('DD/MM/YYYY');

    if(this.route.url.split('/')[1]?.toLowerCase() == 'pos'){
      this.rootModule = this.route.url.split('/')[1]
      this.isPosDashboard = true
      this.isTrackingDashboard = false;
        this.requiredMasterData(this.searchMasterFilter[0].MasterModuleCode, this.searchMasterFilter[0].Id);  // Main Dropdown datepicker section
    }
    else if(this.route.url.split('/')[1]?.toLowerCase() == 'mainsite'){
      this.rootModule = this.route.url.split('/')[1]
      this.isTrackingDashboard = true;
      this.isPosDashboard = false
      this.requiredMasterData(this.searchMasterFilter[1].MasterModuleCode, this.searchMasterFilter[1].Id);  // Main Dropdown datepicker section
    } 

    else if( this.route.url?.includes(this.staticurls.PatientsDashboard)) {
      this.rootModule = this.route.url.split('/')[1]
      this.isPosDashboard = false
      this.isTrackingDashboard = false;
        this.requiredMasterData(this.searchMasterFilter[2].MasterModuleCode, this.searchMasterFilter[2].Id);
    }
    else if( this.route.url?.includes(this.staticurls.InventoryDashboard)) {
      this.rootModule = this.route.url.split('/')[1]
      this.isPosDashboard = false
      this.isTrackingDashboard = false;
        this.requiredMasterData(this.searchMasterFilter[0].MasterModuleCode, this.searchMasterFilter[0].Id);
    }
    else{
      this.isPosDashboard = false;
      this.isTrackingDashboard = false;
      this.getSchema();
    }

    if (this.route.url == StatisURLs.TicketCRM) {
      this.GetMasters(MasterData.Project);
      this.GetMasters(MasterData.Category);
    }
  }
  /**
   * @description - This method will call only for Ticket CRM dashboard data.
   * It will fetch the data for Project and Category dropdown.
   * @param code -- Based on code the data will be fetched from API.
   */
  GetMasters(code:string){
    try {

    let req = {
      Active: "true",
      MasterDataCode: code
    }
    this.api.postService(GetMastersAPI,req).subscribe({
      next: (res: any) => {
        if(res && res.Data && res.Data.length >0){
          this.dropdownDataObj[code]= res.Data;
          // console.log(code,this.dropdownDataObj[code]);
          
        }else{
          this.dropdownDataObj[code]=[];
        }
      },
      error: (error: any) => {
        console.log(code,error);
        this.dropdownDataObj[code]=[];
      }
    });  
  } catch (error) {
      console.log(error);
      
  }
  }


  getSchema() {

    let req:any={
     Code: this.moduleId,
     SearchTypeId : '1'
    }
    // if(this.isTrackingDashboard){
    //   req.Code = SchemaMasterGUID.MainSiteSchema
    // }else{
    //   req.Code = this.moduleId
    // }
      let url:string ='';
      if(this.apiEndPointUrl){
        url = `${environment.APIURL}/${this.apiEndPointUrl}/api/GetDashBoardSummary`;
      }else{
        url = GetDashBoardDetails;
      }
    this.api.postService(url, req).subscribe({
      next: (res: any) => {
      if (res && res.Data && res.ReturnCode == 0) {
        this.graphData = JSON.parse(JSON.stringify(res))
        // this.graphFields = this.graphData.Data;
        
        this.graphFields = this.graphData.Data?.filter((elment:any)=> elment.ModuleId == this.moduleId)

        this.graphFields.forEach((el: any) => {
        if (el.DropdownData && el.DropdownData.length > 0) {
          this.searchMasterFilter.DependantDropdown = el.DropdownData[0].Id
          el.DropdownData.forEach((dropdownEl: any) => {
            if (dropdownEl && dropdownEl.MasterAPIUrl == 'Getmasters') {
              this.requiredMasterData(dropdownEl.MasterModuleCode, dropdownEl.Id,'inner')
            }
          });
        }
        })
        
        this.graphFields.forEach((el: any) => {

          if (el.MasterModuleCode && el.MasterAPIUrl) {

            let req: any = {
              Code: el.MasterModuleCode,
              FromDate: this.fromDate,
              ToDate: this.toDate,
              SearchTypeId: '2',
            };
            if (this.route.url == StatisURLs.TicketCRM) {
              req['Code2'] = ''
              req['Code3'] = ''
            }

            if (this.isPosDashboard) {
              req.Code1 = this.dropdownDataObj['userstore'].map((item: any) => item.Id).join(',') || ''
            } 
            if (!this.isPosDashboard && !this.isTrackingDashboard && this.route.url?.includes(this.staticurls.InventoryDashboard)) {
              req['Code1'] = this.dropdownDataObj[MasterData.stote].map((item: any) => item.Id).join(',') || ''
            }
            if (!this.isPosDashboard && !this.isTrackingDashboard && this.route.url?.includes(this.staticurls.PatientsDashboard)) {
              req['Code1'] = this.dropdownDataObj[MasterData.Healthcare].map((item: any) => item.Id).join(',') || ''
            }
            if (this.isTrackingDashboard) {
              req.IsLog = 'true';
              req.Code1 = this.dropdownDataObj[MasterData.site].map((item: any) => item.Id).join(',') || ''
            }

            this.getGraphDataAPICall(req, el)
          }
        })
      } else{
        this.common.changeIsFailureeMessage(true);
        this.common.changeResponseMessage(res.ReturnMessage);
      }
      }
    })
  }

  getGraphDataAPICall(req: any, chart: any,isSubDropDownChange?:boolean, isLoading?:boolean) {
    if(!isSubDropDownChange){
    if(this.rootModule?.toLowerCase()=='pos' && this.selectedMasterDropDown && Object.keys(this.selectedMasterDropDown)?.length>0){
      this.dropdownDataObj[this.searchMasterFilter[0].DependantDropdown] = Object.values(this.selectedMasterDropDown);
      this.chartDropdownvalue[this.searchMasterFilter[0].DependantDropdown] =  Object.values(this.selectedMasterDropDown);
    }else{
      this.dropdownDataObj[this.searchMasterFilter[0].DependantDropdown] = this.dropdownDataObj[this.searchMasterFilter[0]?.Id];
      this.chartDropdownvalue[this.searchMasterFilter[0].DependantDropdown] =  Object.values(this.selectedMasterDropDown);
    }
  }
  let url:string ='';
  if(this.apiEndPointUrl){
    url = `${environment.APIURL}/${this.apiEndPointUrl}/api/${chart.MasterAPIUrl}`;
  }else{
    url = this.apiPrefixURL + chart.MasterAPIUrl;
  }
    this.api
      .postService(url, req)
      .subscribe({
        next: (res: any) => {
          // this.api
          //   .getService(chart.MasterAPIUrl)
          //   .subscribe({
          //     next: (res: any) => {
            if(!isLoading){
              this.isSubmitLoading = false;
            }

          if (res && res.Data && res.ReturnCode == 0) {
            
            if (this.graphTypesArray.includes(chart.Type?.toLowerCase())) {

              try {
                this.chartOptions[chart.Id] = this.getChartOption(chart, res.Data);
              } catch (error) {
                console.log("Chart settings are missed for", chart.Id)
              }
              // this.chartOptions[chart.Id] = this.setNoDataOptions(chart)
            } else if (chart.Type?.toLowerCase() == 'list' || chart.Type?.toLowerCase() ==  'ipaddresslist') {
              this.otherChartsData[chart.Id] = this.processListResponse(res)
            } 
            else {
              // this.otherChartsData[chart.Id] = this.getChartFormatedData(chart, res.Data);
              this.otherChartsData[chart.Id] = res.Data;
            }
            // console.log(this.otherChartsData, this.chartOptions)
          }else{
            if (this.graphTypesArray.includes(chart.Type?.toLowerCase())){
              this.chartOptions[chart.Id] = this.setNoDataOptions(chart)
            }else{
              this.otherChartsData[chart.Id] = []
            }
          }
        },
        error: (err: any) => {
          console.log(err);
          if(!isLoading){
            this.isSubmitLoading = false;
          }
          if (this.graphTypesArray.includes(chart.Type?.toLowerCase())){
            this.chartOptions[chart.Id] = this.setNoDataOptions(chart)
          }
          else{
            this.otherChartsData[chart.Id] = []
          }
        }
      });
  }

  processListResponse(res: any) {
    let headerArr: any = [];
    let tableDataArr: any = [];
    let tableData: any = [];
    
    if (res != undefined && res != null && res != '') {
      if (res.Headers != undefined && res.Headers != null && res.Headers != '') {
        let header: any = res.Headers;
        header.forEach((item: any) => {

          if (
            item.HeaderName != 'DateCreated' ||
            item.HeaderDisplayName != 'Date Created'
          ) {
            let headerData: any = item.HeaderName;
            let headerName: any = item.HeaderDisplayName;
            headerArr.push(headerName);
            tableDataArr.push(headerData);
          }
        });
      }

      if (res.Data != undefined && res.Data != null && res.Data != '') {
        tableData = res.Data;
      }
    }

    return { headerArr, tableDataArr, tableData };
  }


  calculateFontSize(value: any, count: any) {
    const valueLength = value?.length;
    const charMinCount = count.TotalCharMinCount;
    const charMaxCount = count.TotalCharMaxCount;

    // Set the minimum and maximum font sizes
    const minFontSize = 14;
    const maxFontSize = 20;

    // Calculate the font size based on the character length
    let fontSize;
    if (valueLength <= charMinCount) {
      fontSize = maxFontSize;
    } else if (valueLength >= charMaxCount) {
      fontSize = minFontSize;
    } else {
      // Calculate font size for middle range
      const fontSizeRange = maxFontSize - minFontSize;
      const charRange = charMaxCount - charMinCount;
      const decrementStep = fontSizeRange / charRange;
      fontSize = maxFontSize - ((valueLength - charMinCount) * decrementStep);
    }

    return fontSize;
  }

  getChartOption(chart: any, responseData: any): EChartsOption {
    let option: EChartsOption = {};
    switch (chart.Type) {

      case 'horizontalbar':
        // if (responseData) {
        if (chart.Type == 'horizontalbar') {
          let data = JSON.parse(JSON.stringify(responseData));

          let barChartSettings = chart?.BarChartSetting?.[0] ?? null
          let legendSettings = chart?.LegendSettings?.[0] ?? null
          let labelSettinds = chart?.ChartLabelSettings?.[0] ?? null
          let colorsData = chart?.Colors?.[0] ?? null
          let XaxisLableSettings = chart?.XaxisLableSettings?.[0] ?? null
          let YaxisLableSettings = chart?.YaxisLableSettings?.[0] ?? null
          let labelConfig:any = undefined;
          // let isInsideandTopLabel:boolean = false;
          let tooltipConfig:any =undefined;

          
          if(labelSettinds && labelSettinds.ShowChartLabels){
            if(labelSettinds.ChartLabelFormatter?.toLowerCase() == 'custom' && 
            labelSettinds.ChartLabelPosition?.toLowerCase() =='insideandtop'){

            // isInsideandTopLabel = true;
              labelConfig = {
                show: true,
                position: 'insideTop',
                formatter: (params: any) => {
                  return `{top| ${params.data.value}}\n{bottom|${params.data.labelValue}}`;
                },
                rich: {
                  top: {
                    align: 'center',
                    verticalAlign: 'bottom',
                    padding: [-20, 0, 10, 0], // Adjust padding to position label above the bar
                    color: '#000',
                    fontSize: 12
                  },
                  bottom: {
                    align: 'center',
                    verticalAlign: 'top',
                    padding: [0, 0, 0, 0], // Adjust padding to position label inside the top of the bar
                    color: '#000',
                    fontSize: 12,
                  }
                }
              }

            }else{
              // isInsideandTopLabel = false
              labelConfig = {
                show: true,
                position: labelSettinds.ChartLabelPosition, // or 'outside', 'insideBottom', etc.
                formatter: labelSettinds.ChartLabelFormatter,
                rotate: labelSettinds.ChartLableAngle
              }
            }
          }else{
            labelConfig = { show: false };
            // isInsideandTopLabel = false
          }

          if(barChartSettings && barChartSettings.ShowToolTip){
            if(barChartSettings.ToolTipFormat?.toLowerCase() == 'valueandcount'){
              tooltipConfig = {
                trigger: 'axis',
                axisPointer: {
                  type: 'shadow'
                },
                formatter: function (params: any) {
                  let result = params[0].marker + '&nbsp;' + params[0].name + '<br/>';
                  params.forEach((item: any) => {
                    result += 'Count: &nbsp;&nbsp; <span style="float:right; font-weight:bold;">' + item.data.value + '</span><br/>';
                    if (item.data.labelValue) {
                      result += 'Value: &nbsp;&nbsp; <span style="float:right; font-weight:bold;">' + item.data.labelValue + '</span><br/>';
                    }
                  });
                  return result;
                }
              }
            }else{
              tooltipConfig= {
                trigger: 'axis',
                axisPointer: {
                  type: 'shadow'
                }
              }
            }

          }else{
            tooltipConfig= {
              trigger: 'axis',
              axisPointer: {
                type: 'shadow'
              }
            };
          }

          let colors = {
            "ItemLevel": colorsData && colorsData.ItemLevel ? colorsData.ItemLevel?.trim() && colorsData.ItemLevel.split(',') : null,
          "SeriesLevel": colorsData && colorsData.SeriesLevel ? colorsData.SeriesLevel?.trim() && colorsData.SeriesLevel.split(','): null,
          "AreaLevel": colorsData && colorsData.AreaLevel ? colorsData.AreaLevel?.trim() && colorsData.AreaLevel.split(','): null,
          "GaugeProgress": colorsData && colorsData.GaugeProgress ? colorsData.GaugeProgress?.trim() && colorsData.GaugeProgress.split(',') : null
          }

          const legendConfig = legendSettings ? legendSettings.ShowLegend
            ? {
              data: data.map((item: any) => item.SeriesName),
              orient: legendSettings.LegendOrient || "horizontal",
              ...(legendSettings.LegendPosition ? { [legendSettings.LegendPosition]: 0 } : {}),
              itemWidth: legendSettings.LegendWidth ?? 14,
              itemHeight: legendSettings.LegendHeight ?? 14,
              padding: [20, 0, 0, 0],
            } : { show: false } : { show: false };

            
          // const labelConfig = labelSettinds ? labelSettinds.ShowChartLabels
          //   ? {
          //     show: true,
          //     position: labelSettinds.ChartLabelPosition, // or 'outside', 'insideBottom', etc.
          //     formatter: labelSettinds.ChartLabelFormatter,
          //     rotate: labelSettinds.ChartLableAngle
          //   }
          //   : { show: false } : { show: false };

          option = {
            legend: legendConfig,
            grid: {
              left: '5%',
              right: '5%',
              bottom: '5%',
              top: '5%',
              containLabel: true
            },
            tooltip: tooltipConfig,
            // tooltip: {
            //   // trigger: 'axis',
            //   // axisPointer: {
            //   //   type: 'shadow'
            //   // }
            // },
            toolbox: chart.DownloadChart ? {
              feature: {
                saveAsImage: {
                  name : chart.Label
                }
              }
            } : undefined,
            xAxis: {
              type: 'category',
              position: (XaxisLableSettings?.LabelPosition as XAxisLabelPosition) || "bottom",
              data: data[0]?.SeriesValues?.map((item: any) => item?.Xvalues) || [],
              axisLabel: {
                rotate: XaxisLableSettings?.LabelAngle || 0,
                formatter: '{value}'
              },
              splitLine: {
                show: XaxisLableSettings?.ShowSplitLine ?? true,
                lineStyle: {
                  type: XaxisLableSettings?.SplitLineStyle || undefined
                }
              }
            },
            yAxis: {
              type: 'value',
              minInterval: 1,
              position: (YaxisLableSettings?.LabelPosition as YAxisLabelPosition) || "left",
              axisLabel: {
                rotate: YaxisLableSettings?.LabelAngle || 0,
                formatter: barChartSettings && barChartSettings.CurrencyConvert ? function (value:any){
                  if (value >= 10000000) {
                    return (value / 10000000) + ' Cr'; // Convert lakhs to crores
                  }
                  if(value >= 100000){
                    return value / 100000 + ' L';
                  }if(value >= 1000){
                    return value / 1000 + ' K';
                  }else{
                    return value
                  }
                  // Default to lakhs if less than 10 crores
                } : '{value}'
              },
              splitLine: {
                show: YaxisLableSettings?.ShowSplitLine ?? true,
                lineStyle: {
                  type: YaxisLableSettings?.SplitLineStyle || undefined
                }
              }
            },
            series: (data ?? []).map((seriesData: any, index: number) => ({
              name: seriesData.SeriesName || '',
              type: 'bar',
              stack: barChartSettings && barChartSettings.CombinedSeries ? 'total' : undefined,
              data: (seriesData.SeriesValues ?? []).map((item: any, itemIndex: number) => {
                const barRadius = chart?.ChartBarRadious ?? 0;
                const itemColor = Array.isArray(colors?.ItemLevel) ? colors.ItemLevel[itemIndex] : undefined;
                return ({
                value: item.Yvalues,
                labelValue:item.Y1values || '',
                itemStyle: {
                  color: chart?.ItemLevelColors ? itemColor : undefined,
                  borderRadius: item?.Yvalues < 0 ? [0, 0, barRadius, barRadius] : [barRadius, barRadius, 0, 0]
                }
              });
            }),
              itemStyle: {
                color: chart?.SeriesLevelColors && Array.isArray(colors?.SeriesLevel) ? colors.SeriesLevel[index] : undefined,
              },
              barWidth: chart.ChartBarWidth || '60%',
              label: labelConfig
            }))
          };
        }
        // console.log(option)
        break;

      case 'verticalbar':
        // if (responseData) {
        if (chart.Type == 'verticalbar') {
          let data = JSON.parse(JSON.stringify(responseData))

          let barChartSettings = chart?.BarChartSetting?.[0] ?? null
          let legendSettings = chart?.LegendSettings?.[0] ?? null
          let labelSettinds = chart?.ChartLabelSettings?.[0] ?? null
          let colorsData = chart?.Colors?.[0] ?? null
          let XaxisLableSettings = chart?.XaxisLableSettings?.[0] ?? null
          let YaxisLableSettings = chart?.YaxisLableSettings?.[0] ?? null

          let colors = {
            "ItemLevel": colorsData && colorsData.ItemLevel ? colorsData.ItemLevel?.trim() && colorsData.ItemLevel.split(',') : null,
          "SeriesLevel": colorsData && colorsData.SeriesLevel ? colorsData.SeriesLevel?.trim() && colorsData.SeriesLevel.split(','): null,
          "AreaLevel": colorsData && colorsData.AreaLevel ? colorsData.AreaLevel?.trim() && colorsData.AreaLevel.split(','): null,
          "GaugeProgress": colorsData && colorsData.GaugeProgress ? colorsData.GaugeProgress?.trim() && colorsData.GaugeProgress.split(',') : null
          }

          const legendConfig = chart.LegendSettings ? legendSettings.ShowLegend
            ? {
              data: data.map((item: any) => item.SeriesName),
              orient: legendSettings.LegendOrient || "horizontal",
              ...(legendSettings.LegendPosition ? { [legendSettings.LegendPosition]: 0 } : {}),
              itemWidth: legendSettings.LegendWidth ?? 14,
              itemHeight: legendSettings.LegendHeight ?? 14,
            } : { show: false } : { show: false };
          const labelConfig = chart.ChartLabelSettings ? labelSettinds.ShowChartLabels
            ? {
              show: true,
              position: labelSettinds.ChartLabelPosition, // or 'outside', 'insideBottom', etc.
              formatter: labelSettinds.ChartLabelFormatter,
              rotate: labelSettinds.ChartLableAngle,
              padding: [20, 0, 0, 0],
            }
            : { show: false } : { show: false };

          option = {
            legend: legendConfig,
            grid: {
              left: '5%',
              right: '5%',
              bottom: '5%',
              top: '5%',
              containLabel: true
            },
            tooltip: {
              // trigger: 'axis',
              // axisPointer: {
              //   type: 'shadow'
              // }
            },
            toolbox: chart.DownloadChart ? {
              feature: {
                saveAsImage: {
                  name : chart.Label
                }
              }
            } : undefined,
            xAxis: {
              type: 'value',
              position: (XaxisLableSettings?.LabelPosition as XAxisLabelPosition) || "bottom",
              axisLabel: {
                rotate: XaxisLableSettings?.LabelAngle || 0,
                formatter: '{value}',
              },
              splitLine: {
                show: XaxisLableSettings?.ShowSplitLine ?? true,
                lineStyle: {
                  type: XaxisLableSettings?.SplitLineStyle || undefined
                }
              }
            },
            yAxis: {
              type: 'category',
              position: (YaxisLableSettings?.LabelPosition as YAxisLabelPosition) || "left",
              data: data[0]?.SeriesValues?.map((item: any) => item.Xvalues) || [],
              axisLabel: {
                rotate: YaxisLableSettings?.LabelAngle || 0,
                formatter: '{value}'
              },
              splitLine: {
                show: YaxisLableSettings?.ShowSplitLine ?? true,
                lineStyle: {
                  type: YaxisLableSettings?.SplitLineStyle || undefined
                }
              }
            },

            series: data.map((seriesData: any, index: number) => ({
              name: seriesData.SeriesName,
              type: 'bar',
              stack: barChartSettings && barChartSettings.CombinedSeries ? 'total' : undefined,
              data: (seriesData.SeriesValues ?? []).map((item: any, itemIndex: number) => {
                const barRadius = chart?.ChartBarRadious ?? 0;
                const itemColor = Array.isArray(colors?.ItemLevel) ? colors.ItemLevel[itemIndex] : undefined;
                return ({
                value: item.Yvalues,
                itemStyle: {
                  color: chart?.ItemLevelColors ? itemColor : undefined,
                  borderRadius: item?.Yvalues < 0 ? [barRadius, 0, 0, barRadius] : [0, barRadius, barRadius, 0]
                }
              });
            }),
              itemStyle: {
                color: chart?.SeriesLevelColors && Array.isArray(colors?.SeriesLevel) ? colors.SeriesLevel[index] : undefined,
              },
              barWidth: chart.ChartBarWidth || '60%',
              label: labelConfig
            }))
          };
        }
        break;

      case 'line':
        // if (responseData) {
        if (chart.Type == 'line') {
          let data = JSON.parse(JSON.stringify(responseData))

          let lineChartSettings = chart?.LineChartSettings?.[0] ?? null
          let legendSettings = chart?.LegendSettings?.[0] ?? null
          let labelSettinds = chart?.ChartLabelSettings?.[0] ?? null
          let colorsData = chart?.Colors?.[0] ?? null
          let XaxisLableSettings = chart?.XaxisLableSettings?.[0] ?? null
          let YaxisLableSettings = chart?.YaxisLableSettings?.[0] ?? null
          let tooltipConfig:any =undefined;

          if(lineChartSettings && lineChartSettings.ShowToolTip){
            if(lineChartSettings.ToolTipFormat?.toLowerCase() == 'valueandcount'){
              tooltipConfig = {
                trigger: 'item',
                axisPointer: {
                  type: 'line',
                  axis: 'auto'
                },
                formatter: function (params: any) {
                  let result = params.marker + '&nbsp;' + params.name + '<br/>';
                  if (params.data) {
                    result += 'Count: &nbsp;&nbsp; <span style="float:right; font-weight:bold;">' + params.data.value + '</span><br/>';
                    if (params.data.labelValue) {
                      result += 'Value: &nbsp;&nbsp; <span style="float:right; font-weight:bold;">' + params.data.labelValue + '</span><br/>';
                    }
                  }
                  return result;
                }
              }
            }else{
              tooltipConfig= {
                 trigger: 'item',
                  axisPointer: {
                    type: 'line'
                  },
              }
            }

          }else{
            tooltipConfig= {
              trigger: 'item',
               axisPointer: {
                 type: 'line'
               },
           };
          }

          let colors = {
            "ItemLevel": colorsData && colorsData.ItemLevel ? colorsData.ItemLevel?.trim() && colorsData.ItemLevel.split(',') : null,
          "SeriesLevel": colorsData && colorsData.SeriesLevel ? colorsData.SeriesLevel?.trim() && colorsData.SeriesLevel.split(','): null,
          "AreaLevel": colorsData && colorsData.AreaLevel ? colorsData.AreaLevel?.trim() && colorsData.AreaLevel.split(','): null,
          "GaugeProgress": colorsData && colorsData.GaugeProgress ? colorsData.GaugeProgress?.trim() && colorsData.GaugeProgress.split(',') : null
          }

          const legendConfig = legendSettings ? legendSettings.ShowLegend
            ? {
              data: data.map((item: any) => item.SeriesName),
              orient: legendSettings.LegendOrient || "horizontal",
              ...(legendSettings.LegendPosition ? { [legendSettings.LegendPosition]: 0 } : {})
            } : { show: false } : { show: false };
          const labelConfig = labelSettinds ? labelSettinds.ShowChartLabels
            ? {
              show: true,
              position: labelSettinds.ChartLabelPosition, // or 'outside', 'insideBottom', etc.
              formatter: labelSettinds.ChartLabelFormatter,
              rotate: labelSettinds.ChartLableAngle,
              padding: [10, 0, 0, 0],
            }
            : { show: false } : { show: false };


          option = {
            legend: legendConfig,
            grid: {
              left: '5%',
              right: '5%',
              bottom: '5%',
              top: '5%',
              containLabel: true
            },
            tooltip:tooltipConfig,
            // tooltip: {
            //   // trigger: 'axis',
            //   // axisPointer: {
            //   //   type: 'cross',
            //   //   label: {
            //   //     backgroundColor: '#6a7985'
            //   //   }
            //   // }
            // },
            toolbox: chart.DownloadChart ? {
              feature: {
                saveAsImage: {
                  name : chart.Label
                }
              }
            } : undefined,
            xAxis: {
              type: 'category',
              data: data[0]?.SeriesValues?.map((item: any) => item.Xvalues) || [],
              axisLabel: {
                rotate: XaxisLableSettings?.LabelAngle || 0,
                formatter: '{value}',
                margin:10
              },
            },
            yAxis: {
              type: 'value',
              minInterval: 1,
              axisLabel: {
                rotate: YaxisLableSettings?.LabelAngle || 0,
                formatter: '{value}',
                margin:10
              },
            },
            series: (data ?? []).map((seriesData: any, index: number) => ({
              name: seriesData.SeriesName || '',
              type: 'line',
              data: (seriesData.SeriesValues ?? []).map((item: any) => ({
                value: item.Yvalues,
                labelValue: item.Y1values // Add label value
              })),
              smooth: lineChartSettings && lineChartSettings.LineSmooth || false,
              stack: 'Total',
              emphasis: {
                focus: 'series'
              },
              areaStyle: chart.AreaLevelColors && lineChartSettings && lineChartSettings.AreaLevelColors
                ? {
                  color: chart.AreaLevelColors && colors && colors.AreaLevel ? colors.AreaLevel[index] : undefined  // Default color if not provided
                }
                : undefined,
              lineStyle: {
                color: chart?.SeriesLevelColors && Array.isArray(colors?.SeriesLevel) ? colors.SeriesLevel[index] : undefined,
              },
              label: labelConfig
            }))
          };

        }
        break;

      case 'pie':
        // if (responseData) {
        if (chart.Type == 'pie') {

          let data = JSON.parse(JSON.stringify(responseData))
          
          let donutSettings = chart.DonutChartSettings && chart.DonutChartSettings[0] || null
          let legendSettings = chart.LegendSettings && chart.LegendSettings[0] || null
          let labelSettinds = chart.ChartLabelSettings && chart.ChartLabelSettings[0] || null
          let colorsData =   chart.Colors && chart.Colors[0] || null

          let colors = {
            "ItemLevel": colorsData && colorsData.ItemLevel ? colorsData.ItemLevel?.trim() && colorsData.ItemLevel.split(',') : null,
          "SeriesLevel": colorsData && colorsData.SeriesLevel ? colorsData.SeriesLevel?.trim() && colorsData.SeriesLevel.split(','): null,
          "AreaLevel": colorsData && colorsData.AreaLevel ? colorsData.AreaLevel?.trim() && colorsData.AreaLevel.split(','): null,
          "GaugeProgress": colorsData && colorsData.GaugeProgress ? colorsData.GaugeProgress?.trim() && colorsData.GaugeProgress.split(',') : null
          }

          const legendConfig = legendSettings ? legendSettings.ShowLegend
            ? {
              // data: data.map((item: any) => item.SeriesName),
              orient: legendSettings.LegendOrient || "horizontal",
              ...(legendSettings.LegendPosition ? { [legendSettings.LegendPosition]: 0 } : {}),
              itemWidth: legendSettings.LegendWidth ?? 14,
              itemHeight: legendSettings.LegendHeight ?? 14,
              formatter: legendSettings.LegendFormatter ?? undefined,
              padding: [30, 0, 0, 0],
              itemGap: 8,

            } : { show: false } : { show: false };

            const labelConfig = labelSettinds ? labelSettinds.ShowChartLabels
            ? {
              show: true,
              position: labelSettinds.ChartLabelPosition, // or 'outside', 'insideBottom', etc.
              formatter: labelSettinds.ChartLabelFormatter,
              rotate: labelSettinds.ChartLableAngle,
              // color: '#000000'
            }
            : { show: false } : { show: false };

          option = {
            legend: legendConfig,
            grid: {
              left: '5%',
              right: '5%',
              bottom: '5%',
              top: '5%',
              containLabel: true
            },
            tooltip: {
              trigger: 'item',
              formatter: '{b}: {c} ({d}%)',
            },
            toolbox: chart.DownloadChart ? {
              feature: {
                saveAsImage: {
                  name : chart.Label
                }
              }
            } : undefined,
            series: data.map((seriesData: any, index: number) => ({
              // name: seriesData.SeriesName || false,
              type: 'pie',
              radius: chart.PieChartWidth || '50%',
              center: ['50%', '40%'], 
              data: (seriesData.SeriesValues ?? []).map((item: any, itemIndex: number) => ({
                name: item.Xvalues,
                value: item.Yvalues,
                itemStyle: {
                  color: chart?.SeriesLevelColors && Array.isArray(colors?.SeriesLevel) ? colors.SeriesLevel[itemIndex] : undefined,
                },
              })),
              emphasis: {
                itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
              },
              label: labelConfig
            }))
          };
        }
        break;

      case 'donut':
        // if (responseData) {
        if (chart.Type == 'donut') {

          let data = JSON.parse(JSON.stringify(responseData))
          const totalValueWithDecimal = data[0].SeriesValues.reduce((acc: number, cur: any) => acc + cur.Yvalues, 0);
          const totalValue = totalValueWithDecimal % 1 !== 0 ? totalValueWithDecimal.toFixed(2) : totalValueWithDecimal.toString();

          let donutSettings = chart.DonutChartSettings && chart.DonutChartSettings[0] || null
          let legendSettings = chart.LegendSettings && chart.LegendSettings[0] || null
          let labelSettinds = chart.ChartLabelSettings && chart.ChartLabelSettings[0] || null
          let colorsData =   chart.Colors && chart.Colors[0] || null

          let colors = {
            "ItemLevel": colorsData && colorsData.ItemLevel ? colorsData.ItemLevel?.trim() && colorsData.ItemLevel.split(',') : null,
          "SeriesLevel": colorsData && colorsData.SeriesLevel ? colorsData.SeriesLevel?.trim() && colorsData.SeriesLevel.split(','): null,
          "AreaLevel": colorsData && colorsData.AreaLevel ? colorsData.AreaLevel?.trim() && colorsData.AreaLevel.split(','): null,
          "GaugeProgress": colorsData && colorsData.GaugeProgress ? colorsData.GaugeProgress?.trim() && colorsData.GaugeProgress.split(',') : null
          }


          let getTitleText = donutSettings && donutSettings.TotalTitleDisplay ? donutSettings.TotalTitleText : undefined;
          let valueStr = `${totalValue}`;
          let titleStr = getTitleText ? `${getTitleText}` : '';
          let dynamicFontSize = this.calculateFontSize(valueStr, donutSettings);
          let dynamicTextFontSize = titleStr ? this.calculateFontSize(titleStr, donutSettings) : '';

          let titleText = '';
          if (donutSettings) {
            if (donutSettings.TotalTitleDisplay) {
              titleText += `{title|${donutSettings.TotalTitleText || 'Total'}}`;
            }
            if (donutSettings.TotalTitleDisplay && donutSettings.TotalCountDisplay) {
              titleText += '\n\n'; // Adding gap if both conditions are true
            }
            if (donutSettings.TotalCountDisplay) {
              titleText += `{value|${totalValue}}`;
            }
          }


          const legendConfig = legendSettings ? legendSettings.ShowLegend
            ? {
              // data: data.map((item: any) => item.SeriesName),
              orient: legendSettings.LegendOrient || "horizontal",
              ...(legendSettings.LegendPosition ? { [legendSettings.LegendPosition]: 0 } : {}),
              itemWidth: legendSettings.LegendWidth ?? 14,
              itemHeight: legendSettings.LegendHeight ?? 14,
              formatter: legendSettings.LegendFormatter ?? undefined,
              padding: [20, 0, 0, 0],

            } : { show: false } : { show: false };

          const labelConfig = labelSettinds ? labelSettinds.ShowChartLabels
            ? {
              show: true,
              position: labelSettinds.ChartLabelPosition, // or 'outside', 'insideBottom', etc.
              formatter: labelSettinds.ChartLabelFormatter,
              rotate: labelSettinds.ChartLableAngle
            }
            : { show: false } : { show: false };

          option = {
            legend: legendConfig,
            grid: {
              left: '5%',
              right: '5%',
              bottom: '5%',
              top: '5%',
              containLabel: true
            },
            tooltip: {
              trigger: 'item',
              formatter: '{b}: {c} ({d}%)',
            },
            toolbox: chart.DownloadChart ? {
              feature: {
                saveAsImage: {
                  name : chart.Label
                }
              }
            } : undefined,
            title: donutSettings ? donutSettings.TotalCountDisplay ? {
              text: titleText,
              left: 'center',
              top: 'center',
              textStyle: {
                rich: {
                  title: {
                    fontSize: dynamicTextFontSize || 0, // Set the font size for "Total Ticket"
                    fontWeight: 'bold',
                    align: 'center'
                  },
                  value: {
                    fontSize: dynamicFontSize, // Set the dynamic font size for the total value
                    fontWeight: 'bold',
                    align: 'center'
                  }
                }
              }
            } : { show: false } : { show: false },
            series: data.map((seriesData: any, index: number) => ({
              // name: seriesData.SeriesName || false,
              type: 'pie',
              radius: chart.DonutChartWidth?.split(',') || ["30%", "70%"],
              data: (seriesData.SeriesValues ?? []).map((item: any, itemIndex: number) => ({
                name: item.Xvalues,
                value: item.Yvalues,
                itemStyle: {
                  color: colors && colors.ItemLevel? colors.ItemLevel[itemIndex] || undefined : undefined,
                },
              })),
              label: labelConfig

            }))
          };
        }
        break;

      case 'gauge':
        // if (responseData) {
        if (chart.Type == 'gauge') {

          // let gaugeSettingsData = chart.GaugeChartSettings && chart.GaugeChartSettings[0] || null
          // let legendSettings = chart.LegendSettings && chart.LegendSettings[0] || null
          // let labelSettinds = chart.ChartLabelSettings && chart.ChartLabelSettings[0] || null
          let colorsData =   chart.Colors && chart.Colors[0] || null

          // let colors = {
          //   "ItemLevel": colorsData.ItemLevel ? colorsData.ItemLevel.split(',') : null,
          // "SeriesLevel": colorsData.SeriesLevel ? colorsData.SeriesLevel.split(','): null,
          // "AreaLevel": colorsData.AreaLevel ? colorsData.AreaLevel.split(','): null,
          // "GaugeProgress": colorsData.GaugeProgress ? colorsData.GaugeProgress.split(',') : null
          // }

          let data = JSON.parse(JSON.stringify(responseData))
          const seriesValues = data[0].SeriesValues[0];
          const gaugeValue = seriesValues.Yvalues;
          const gaugeName = seriesValues.Xvalues;
          const gaugeSettings = chart.GaugeChartSettings && chart.GaugeChartSettings[0] || null
          const gaugeProgress = colorsData?.GaugeProgress?.trim();
          const color = gaugeProgress ? gaugeProgress.split(',') : ['#add8e6']
          const gaugeColor = Array.isArray(color) ? color[0] : '#add8e6'

          option = {
            grid: {
              left: '5%',
              right: '5%',
              bottom: '5%',
              top: '5%',
              containLabel: true
            },
            toolbox: chart.DownloadChart ? {
              feature: {
                saveAsImage: {
                  name : chart.Label
                }
              }
            } : undefined,
            series: [
              {
                type: 'gauge',
                startAngle: gaugeSettings.AxisStartAngle || 180,
                endAngle: gaugeSettings.AxisEndAngle || 0,
                detail: gaugeSettings.ShowTotalPercentage ? {
                  formatter: '{value}%',
                  fontSize: gaugeSettings.TotalPercentageSize || 24,
                  fontWeight: 'bold',
                  offsetCenter: gaugeSettings.TotalPercentagePosition?.split(',') || [0, '0%']
                } : undefined,
                itemStyle: {
                  color: color
                },
                data: [{ value: gaugeValue, name: gaugeName }],
                axisLine: {
                  roundCap: gaugeSettings.AxisLineRoundCap || false,
                  lineStyle: {
                    width: 30,
                    color: [
                      [gaugeValue / 100, (gaugeColor || '')],
                      [1, '#dcdcdc']
                    ]
                  }
                },
                splitLine: {
                  show: false,
                  distance: 0,
                  length: 10
                },
                axisTick: {
                  show: false
                },
                axisLabel: {
                  show: false,
                  distance: 50
                },
                pointer: gaugeSettings.PointerShow ? {
                  icon: gaugeSettings.PointerIcon,
                  length: gaugeSettings.PointerLength || '75%'
                } : undefined
              }
            ]
          };
        };
        break;

    }
    // console.log(option)
    return option;
  }

  getPermission() {
    this.common.updatePermissionModule
      .pipe(takeUntil(this.destroy$))
      .subscribe((res: any) => {
        if (res) {
          this.modulePermissionObj = res[this.moduleId];
        }
      });
  }

  onDateRangeSelected(start: any, end: any, index: number) {
    this.fromDate = start.format('DD/MM/YYYY')
    this.toDate = end.format('DD/MM/YYYY')
  }

  getProgressColor(percentage: number): string {
    if (percentage <= 50) {
      return 'linear-gradient(90deg, #ff6b6b, #ffcc5c)'; // Red to Yellow for low percentages
    } else if (percentage <= 75) {
      return 'linear-gradient(90deg, #f5a623, #f5f5f5)'; // Orange to Light Grey for medium percentages
    } else {
      return 'linear-gradient(90deg, #E37669, #D59B56, #5AC583)'; // Green to Light Green for high percentages
    }
  }

  getDataByDateRange() {

    
    this.isSubmitLoading = true;
    // console.log("Dropdown Data",this.dropdownDataObj)
    // console.log("Dropdown Data",this.chartDropdownvalue)

    this.graphFields.forEach((el: any, index:number) => {
      if (el.MasterModuleCode && el.MasterAPIUrl) {
        let req: any = {
          Code: el.MasterModuleCode,
          FromDate: this.fromDate,
          ToDate: this.toDate,
          SearchTypeId: '2',
        };
        if(this.route.url == StatisURLs.TicketCRM){
          req['Code2'] = this.selectedProject ||''
          req['Code3'] = this.selectedCategory && this.selectedCategory?.length >0 ?this.selectedCategory?.map((x:any)=>x.Id)?.join()  :''
        }
        if (this.isPosDashboard || this.isTrackingDashboard) {
          req.Code1 = Object.keys(this.selectedMasterDropDown).join(',') || ''
        }
        if (!this.isPosDashboard && !this.isTrackingDashboard) {
          req['Code1'] = Object.values(this.selectedMasterDropDown) && Object.values(this.selectedMasterDropDown)?.length >0 ? Object.values(this.selectedMasterDropDown).map((x:any)=>x.Id).join() :'';
      }
        if(this.isTrackingDashboard){
          req.IsLog = 'true'
        }
        let isLoading = false;
        if(index == this.graphFields?.length-1){
          isLoading = false;
        }else{
          isLoading = true;
        }
        this.getGraphDataAPICall(req, el, false, isLoading)
      }
    })
  }

  routeToPage(url: any) {
    this.route.navigate([`${url}`]);
  }

  detailsPageRoute() {
    this.route.navigate(["/SalesCRM/ActivityManagement/list"]);
  }

  getEmployeeProgress(percentage: number) {
    return '#00a3ff'
  }

  requiredMasterData(code: any, Id: any,type?:string) {
  try {
    let req = {
      Active: 'true',
      MasterDataCode: code,
    };

    this.api.postService(GetMastersAPI, req).subscribe({
      next: (res: any) => {
        if (res && res.Data && res.Data.length > 0) {
          this.dropdownDataObj[Id] = res.Data

          if(Id == 'SalesByCashRegister'){
            this.chartDropdownvalue[Id] = this.dropdownDataObj[Id]
          }
          this.dropdownDataObj[Id].forEach((el: any) => {
            this.selectedMasterDropDown[el.Id] = el
          });
          this.chartParentDropdownvalue = this.dropdownDataObj[Id] // Select all items initially
          // console.log(this.chartParentDropdownvalue)
        } else {
          this.dropdownDataObj[Id] = [];

        if(Id == 'SalesByCashRegister'){
          this.chartDropdownvalue[Id] = this.dropdownDataObj[Id]
        }
        this.selectedMasterDropDown = {}
        this.chartParentDropdownvalue = this.dropdownDataObj[Id]
        }
        if(!type){
          this.getSchema();
        }
      },
      error: (err: any) => {
        console.log(err);
        this.dropdownDataObj[Id] = [];

        if(Id == 'SalesByCashRegister'){
          this.chartDropdownvalue[Id] = this.dropdownDataObj[Id]
        }
        this.selectedMasterDropDown = {}
        this.chartParentDropdownvalue = this.dropdownDataObj[Id]
      }
    })
  } catch (error) {
    console.log(error);
    
  }

  }
  mainStoreSelection(event: any) {
    this.selectedMasterDropDown[event.Id] = {}
    this.selectedMasterDropDown[event.Id] = event;
  }

  selectMasterStore(event: any) {
    this.selectedMasterDropDown[event.Id] = event
  }

  selectAllMasterStore(event: any) {
    if (event && event.length > 0) {
      event.forEach((el: any) => {
        this.selectedMasterDropDown[el.Id] = el
      });
    };
  }

  deselectMasterStore(event: any) {
    delete this.selectedMasterDropDown[event.Id]
  }

  deselecAlltMasterStore(event: any) {
    this.selectedMasterDropDown = {}
  }

  selectedSubDashboard(event:any, type:string, chart:any,id:any){
    if (type === 'select') {
      // this.chartDropdownvalue[id].push(event);
    } else if (type === 'deselect') {
      let val  = Object.values(structuredClone(this.chartDropdownvalue[id]));
      if(val && val.length >0){
        let filteredData = val?.filter((x:any)=>x.Id != event.Id);
        this.chartDropdownvalue[id] = filteredData;
      }
      
    } else if (type === 'selectAll') {
      this.chartDropdownvalue[id] = []
      event.forEach((el: any) => {
        this.chartDropdownvalue[id].push(el)
      });
    } else if (type === 'deselectAll') {
      this.chartDropdownvalue[id] = [];
    }

    let req: any = {
      Code: chart.MasterModuleCode,
      FromDate: this.fromDate,
      ToDate: this.toDate,
      SearchTypeId: '2',
    };

    if (this.isPosDashboard && Object.values(this.chartDropdownvalue[id])?.length >0) {
      let val = Object.values(this.chartDropdownvalue[id])
        req.Code1 = val.map((el:any)=>el.Id).join(',') || ''
    }else{
      req.Code1 = ''
    }

    this.getGraphDataAPICall(req, chart , true)
  }

  setNoImage(event: any) {
    try {
      if (event.target && event.target) {
        event.target.src = './assets/images/member.svg'
      }
    } catch (error) {

    }
  }

  setNoDataOptions(chart:any):EChartsOption{
    let option: EChartsOption = {};
    option = {
      graphic: [
        {
          type: 'group',
          left: 'center',
          top: 'center',
          children: [
            {
              type: 'image',
              id: 'no-records-image',
              style: {
                image: 'assets/images/no-data-found.svg',
                width: 240,
                height: 160,
              },
              left:'center',
              top:'-180'
            },
            {
              type: 'text',
              id: 'no-records-text',
              style: {
                text: 'No Records',
                fontSize: '24px',
                fontWeight:500,
                // font: 'bold 25px sans-serif',
                fill: '#212529',
              },
              left:'center',
              top:'center'
            },
          ],
        },
      ],
    };
    

    return option
  }
}
